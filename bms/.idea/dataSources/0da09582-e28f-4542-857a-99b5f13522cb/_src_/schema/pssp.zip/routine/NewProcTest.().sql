CREATE PROCEDURE NewProcTest()
  begin  
  update spd_number set number=1;
end;
