CREATE FUNCTION mycat_seq_setval(seq_name VARCHAR(50), value INT)
  RETURNS VARCHAR(64)
  BEGIN 
         UPDATE MYCAT_SEQUENCE  
                   SET current_value = value  
                   WHERE name = seq_name;  
         RETURN mycat_seq_currval(seq_name);  
END;
