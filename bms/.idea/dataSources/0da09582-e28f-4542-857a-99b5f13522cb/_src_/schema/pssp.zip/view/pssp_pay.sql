CREATE VIEW pssp_pay AS
  SELECT
    '单笔付款'                                  AS `API_NAME`,
    `pssp`.`pssp_pay_single`.`PAY_AMOUNT`   AS `amount`,
    `pssp`.`pssp_pay_single`.`REQUEST_TIME` AS `REQUEST_TIME`
  FROM `pssp`.`pssp_pay_single`
  UNION ALL SELECT
              '批量付款'                                 AS `批量付款`,
              `pssp`.`pssp_pay_batch`.`PAY_AMOUNT`   AS `amount`,
              `pssp`.`pssp_pay_batch`.`REQUEST_TIME` AS `REQUEST_TIME`
            FROM `pssp`.`pssp_pay_batch`
  UNION ALL SELECT
              '代发工资'                                  AS `代发工资`,
              `pssp`.`pssp_pay_salary`.`PAY_AMOUNT`   AS `amount`,
              `pssp`.`pssp_pay_salary`.`REQUEST_TIME` AS `REQUEST_TIME`
            FROM `pssp`.`pssp_pay_salary`
  UNION ALL SELECT
              '资金调拨'                                 AS `资金调拨`,
              `pssp`.`pssp_pay_inner`.`AMOUNT`       AS `amount`,
              `pssp`.`pssp_pay_inner`.`REQUEST_TIME` AS `REQUEST_TIME`
            FROM `pssp`.`pssp_pay_inner`;
