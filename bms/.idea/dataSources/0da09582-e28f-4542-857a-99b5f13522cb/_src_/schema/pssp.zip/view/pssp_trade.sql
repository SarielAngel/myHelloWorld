CREATE VIEW pssp_trade AS
  SELECT
    `pssp`.`pssp_pay_single`.`PAY_AMOUNT`   AS `amount`,
    `pssp`.`pssp_pay_single`.`REQUEST_TIME` AS `REQUEST_TIME`
  FROM `pssp`.`pssp_pay_single`
  UNION ALL SELECT
              `pssp`.`pssp_pay_batch`.`PAY_AMOUNT`   AS `amount`,
              `pssp`.`pssp_pay_batch`.`REQUEST_TIME` AS `REQUEST_TIME`
            FROM `pssp`.`pssp_pay_batch`
  UNION ALL SELECT
              `pssp`.`pssp_pay_salary`.`PAY_AMOUNT`   AS `amount`,
              `pssp`.`pssp_pay_salary`.`REQUEST_TIME` AS `REQUEST_TIME`
            FROM `pssp`.`pssp_pay_salary`
  UNION ALL SELECT
              `pssp`.`pssp_pay_inner`.`AMOUNT`       AS `amount`,
              `pssp`.`pssp_pay_inner`.`REQUEST_TIME` AS `REQUEST_TIME`
            FROM `pssp`.`pssp_pay_inner`;
