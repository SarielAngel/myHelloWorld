CREATE TRIGGER trigger_rule_no
BEFORE INSERT ON charge_rule
FOR EACH ROW
  BEGIN
set NEW.RULE_NO = nextval('RULE_NO');
END;
