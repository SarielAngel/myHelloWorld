CREATE TRIGGER trigger_profit_no
BEFORE INSERT ON profit_rule
FOR EACH ROW
  BEGIN
set NEW.PROFIT_NO = nextval('PROFIT_NO');
END;
