CREATE TRIGGER trigger_permission_no
BEFORE INSERT ON sys_permission
FOR EACH ROW
  BEGIN
set NEW.PERMISSION_NO = nextval('PERMISSION_NO');
END;
