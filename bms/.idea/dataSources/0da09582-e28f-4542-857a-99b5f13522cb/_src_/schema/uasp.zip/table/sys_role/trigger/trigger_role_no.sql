CREATE TRIGGER trigger_role_no
BEFORE INSERT ON sys_role
FOR EACH ROW
  BEGIN
set NEW.ROLE_NO = nextval('ROLE_NO');
END;
