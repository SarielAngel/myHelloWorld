CREATE TRIGGER trigger_user_no
BEFORE INSERT ON sys_user
FOR EACH ROW
  BEGIN
set NEW.USER_NO = nextval('USER_NO');
END;
