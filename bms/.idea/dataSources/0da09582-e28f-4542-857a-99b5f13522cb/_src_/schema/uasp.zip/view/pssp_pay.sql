CREATE VIEW pssp_pay AS
  (SELECT
     `uasp`.`pssp_inner`.`AMOUNT`       AS `amount`,
     '资金调拨'                             AS `API_NAME`,
     `uasp`.`pssp_inner`.`REQUEST_TIME` AS `REQUEST_TIME`
   FROM `uasp`.`pssp_inner`)
  UNION ALL (SELECT
               `uasp`.`pssp_single`.`PAY_AMOUNT`   AS `amount`,
               '单笔交易'                              AS `API_NAME`,
               `uasp`.`pssp_single`.`REQUEST_TIME` AS `REQUEST_TIME`
             FROM `uasp`.`pssp_single`);
